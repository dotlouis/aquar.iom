import java.util.concurrent.ThreadLocalRandom;
import java.util.Locale;

import org.contest16.*;

import aquar.iom.defense.Distance;

public class Main
{
    static
    {
        System.loadLibrary("jainl16");
    }

    public static void main(String[] args)
    {
        Locale.setDefault(new Locale("en", "US"));

        if (args.length != 2)
        {
            System.out.println("Parameters: ADDRESS PORT");
            return;
        }
        String address = args[0];
        int port = Integer.parseInt(args[1]);
        String name = "Kanye";

        try
        {
            Session s = new Session();
            System.out.format("Connecting to %s:%d...\n", address, port);
            s.connect(address, port);

            System.out.format("Logging in as a player named '%s'...\n", name);
            s.login_player(name);

            System.out.println("Waiting for welcome...");
            Welcome welcome = s.wait_for_welcome();


            GameParameters p = welcome.getParameters();

            System.out.println("Waiting for game starts...");
            s.wait_for_game_starts();

            while (s.is_logged())
            {
                Actions actions = new Actions();
                /*     .
                 *    / \    If you use the same Actions instance on all turns,
                 *   /   \   do NOT forget to clear the previously made actions
                 *  /  !  \  between turns! This can be done by calling the
                 * /       \ Actions.clear() method.
                 * ‾‾‾‾‾‾‾‾‾                                                   */

                System.out.format("Waiting for next turn...\n");
                s.wait_for_next_turn();

                System.out.format("\nTurn %d/%d received!\n", s.current_turn_number(), p.getNb_turns());

                /* The turn content can be accessed via different Session methods:
                 *   - neutral_cells() returns all neutral cells: both initial and non-initial ones
                 *   - player_cells() returns all player cells
                 *   - my_player_cells() returns our player cells
                 *   - ennemy_player_cells() returns player cells that are not ours
                 *   - viruses() returns all viruses
                 *   - players() returns all players */

                
                PlayerCellVector my_pcells = s.my_player_cells();
                for (int i = 0; i < my_pcells.size(); ++i)
                {
                    PlayerCell myCell = my_pcells.get(i);
                    float myCellX = myCell.getPosition().getX();
                    float myCellY = myCell.getPosition().getY();
                    
                    boolean avoidTop = false;
                    boolean avoidBottom = false;
                    boolean avoidLeft = false;
                    boolean avoidRight = false;

                    PlayerCellVector ennemy_pcells = s.ennemy_player_cells();
                    for (int j = 0; i < ennemy_pcells.size(); ++j)
                    {
                        PlayerCell cell = ennemy_pcells.get(j);
                        float distance = Distance.distanceFromCell(myCell, cell, p);
                        if (distance < 3) {
                        	if (cell.getPosition().getX() - myCellX < 0) {
                        		avoidTop = true;
                        	} else {
                        		avoidBottom = true;
                        	}
                        	
                        	if (cell.getPosition().getX() - myCellY < 0) {
                        		avoidLeft = true;
                        	} else {
                        		avoidRight = true;
                        	}
                        }
                    }

                    VirusVector viruses = s.viruses();
                    for (int k = 0; k < viruses.size(); ++k)
                    {
                        Virus virus = viruses.get(k);
                        PlayerCell cell = ennemy_pcells.get(k);
                        float distance = Distance.distance(myCell.getPosition(), virus.getPosition());
                        if (distance < 3) {
                        	if (cell.getPosition().getX() - myCellX < 0) {
                        		avoidTop = true;
                        	} else {
                        		avoidBottom = true;
                        	}
                        	
                        	if (cell.getPosition().getX() - myCellY < 0) {
                        		avoidLeft = true;
                        	} else {
                        		avoidRight = true;
                        	}
                        }
                    }
                    
                    
                    if (avoidBottom && avoidLeft && avoidRight) {
                    	actions.add_move_action(myCell.getPcell_id(), myCellX, myCellY + 2);
                    } else if (avoidTop && avoidLeft && avoidRight) {
                    	actions.add_move_action(myCell.getPcell_id(), myCellX, myCellY - 2);
                    } else if (avoidLeft && avoidRight) {
                    	actions.add_move_action(myCell.getPcell_id(), myCellX, myCellY - 2);
                    } else if (avoidTop && avoidBottom && avoidRight) {
                    	actions.add_move_action(myCell.getPcell_id(), myCellX - 2, myCellY);
                    } else if (avoidTop && avoidBottom && avoidLeft) {
                    	actions.add_move_action(myCell.getPcell_id(), myCellX + 2, myCellY);
                    }
                }
               

                System.out.format("Sending actions...\n");
                s.send_actions(actions);
            }
        }
        catch(java.lang.RuntimeException e)
        {
            e.printStackTrace();
        }
    }
}
